public class task2 {
}


//P-01:
//--- 1. Runtime: -------------------------------
// n = 10000
// Time measured: 0.00100000000000000000 seconds.
// --- 2. Number of operations:  -----------------
import java.util.Random; // ex. once (1 op)

public class Main {
    // Return sum of elements in A[0..N-1]
    // using recursion.
    static int findSum(int A[], int N) {
        if (N <= 0) // ex. n-1 times (1 op)
            return 0; // ex. once (1 op)
        return (findSum(A, N - 1) + A[N - 1]); // ex. n-1 times (3 ops)
    }

    // Driver method
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        Random rd = new Random(); // ex. once (3 ops)
        int[] arr = new int[10000]; // ex. once (3 ops)
        for (int i = 0; i < arr.length; i++) { // n-times (2 ops) + 1op
            arr[i] = rd.nextInt(); // n-times (3 ops)
        }
        long stopTime = System.currentTimeMillis();
        double elapsedTime = (stopTime - startTime) / 1000.0;
        System.out.println(findSum(arr, arr.length)); // ex. once (2 ops)
        System.out.printf("Time measured: %.20f sec.", elapsedTime);
    }
}
// Total operations:
// (n-1)*4 + n*5 +1+1+3+3+1+2 => 4n-4+5n +11 => 9n+7 => ~ 9n
// --- 3. Big-O -------------------------------
// Here n is the number of elements in the array. O(n)
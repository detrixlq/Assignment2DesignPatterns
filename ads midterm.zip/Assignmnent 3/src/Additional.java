public class Additional {
    dbFunctions db = new dbFunctions();
    //db.search_by_price(conn, "products", 560000);

    //db.read_data_from_users(conn);

    //CREATING TABLES
    //db.createTableUsers(conn, "users");
    //db.createTableProducts(conn, "products");
    //db.createTableShoplist(conn, "shoplist");
    //db.createTableHistory(conn, "history");

    //INSERT DATA TO TABLES (EXAMPLE)
    //db.insert_row_to_users(conn,"Kirill","+77777777666");
    //db.insert_row_to_products(conn, "phone", "Samsung", "Galaxy S", "S22 Ultra", 64, 560000);
    //db.insert_row_to_shoplist(conn, "phone Apple iPhone 13 Pro Max, 256Gb", 620000);
    //db.insert_row_to_history(conn, "Ualikhan", "+77777777777", 600000);


    //ADD PRODUCTS (64 DATA)
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S22 Ultra", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S22 Ultra", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S22 Ultra", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S22 Ultra", 512, 660000);
//
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S21+", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S21+", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S21+", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy S", "S21+", 512, 660000);
//
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Flip4", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Flip4", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Flip4", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Flip4", 512, 660000);
//
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Fold4 5G", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Fold4 5G", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Fold4 5G", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Samsung", "Galaxy Z", "Z Fold4 5G", 512, 660000);
//
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro", 512, 660000);
//
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro Max", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro Max", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro Max", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 13", "Pro Max", 512, 660000);
//
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro", 512, 660000);
//
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro Max", 64, 560000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro Max", 128, 600000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro Max", 256, 630000);
//        db.insert_row_to_products(conn, "products", "phone", "Apple", "iPhone 14", "Pro Max", 518, 660000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y920", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y920", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y920", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y920", 512, 600000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y720", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y720", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y720", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "Legion", "Y720", 512, 600000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "X13", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "X13", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "X13", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "X13", 512, 600000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "Z19", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "Z19", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "Z19", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Xiaomi", "ThinkPad", "Z19", 512, 600000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "13GET", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "13GET", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "13GET", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "13GET", 512, 600000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "Z83", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "Z83", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "Z83", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Tab Yoga", "Z83", 512, 600000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "G14", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "G14", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "G14", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "G14", 512, 600000);
//
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "Duo 16", 64, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "Duo 16", 128, 600000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "Duo 16", 256, 560000);
//        db.insert_row_to_products(conn, "products", "laptop", "Lenovo", "Rog Zephyrus", "Duo 16", 512, 600000);


    //delete database (CHANGE TABLE NAME IN "DROP TABLE *tableName*")
//        Statement stmt = conn.createStatement();
//        String query = "DROP TABLE history";
//        stmt.executeUpdate(query);
//        System.out.println("Table deleted in given database...");
}

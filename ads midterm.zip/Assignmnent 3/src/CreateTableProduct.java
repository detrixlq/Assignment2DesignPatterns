import java.sql.Connection;
import java.sql.Statement;

public class CreateTableProduct {
    public void createTableProducts(Connection conn) {
        Statement statement;
        try {
            String query = "create table " + "products" + "(empid SERIAL, type varchar(200), company varchar(200), series varchar(200), model varchar(200), capacity integer, price integer, primary key(empid));";
            statement = conn.createStatement();
            statement.executeUpdate(query);
            System.out.println("Table products Created");
        }catch (Exception e) {
            System.out.println(e);
        }
    }
}

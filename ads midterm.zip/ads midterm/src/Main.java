import java.util.*;
import java.util.Scanner;

class 
class Main{
            public static void main(String[] args){
                Scanner sc = new Scanner(System.in);
                String[] input = sc.nextLine().split(" ");
                for(int i = 0; i < input.length; i++){
                    //insert to list
                }

            }
}
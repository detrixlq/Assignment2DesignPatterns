import java.util.Scanner;

public class Phone {
    private int number;
    private String model;
    private int weight;
    public void setNumber(int number) {
        this.number = number;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public void setWeight(int weight) {
        this.weight = weight;
    }
    public int getNumber() {
        return number;
    }
    public String getModel() {
        return model;
    }
    public int getWeight() {
        return weight;
    }
    public void receiveCall(String name) {
        System.out.println(name + " is ringing");
    }
    public void receiveCall(String name, int number) {
        System.out.println(name + " is ringing with number " + number);
    }
    public void sendMessage() {
        Scanner myObj = new Scanner(System.in);
        System.out.println("Enter number:");

        number = myObj.nextInt();
        System.out.println("The message will be sent to the number " + number);
    }
    public Phone(int number, String model, int weight) {
        this.number = number;
        this.model = model;
        this.weight = weight;
    }
    public Phone() {
    }
    public static void main(String[] args) {
        Phone Phone1 = new Phone (1, "S22", 123);

        Phone1.receiveCall("Ali");
        Phone1.receiveCall("Nurislam", 777);
        Phone1.sendMessage();
    }
}

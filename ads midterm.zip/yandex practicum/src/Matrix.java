
import java.util.Scanner;
public class Matrix {
    private double[][] matrix;
    private int rows;
    private int cols;

    public Matrix(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.matrix = new double[rows][cols];
    }

    public void setValue(int row, int col, double value) {
   //     System.out.println("Enter the matrix' value");
    //    Scanner sc = new Scanner(System.in);
   //     matrix[row][col] = sc.nextInt();
        matrix[row][col] = value;
    }

    public Matrix add(Matrix other) {
        if (this.rows != other.rows || this.cols != other.cols) {
            throw new IllegalArgumentException("Must have the same dimension");
        }
        Matrix result = new Matrix(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.matrix[i][j] = this.matrix[i][j] + other.matrix[i][j];
            }
        }
        return result;
    }

    public Matrix multiply(double scalar) {
        Matrix result = new Matrix(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.matrix[i][j] = this.matrix[i][j] * scalar;
            }
        }
        return result;
    }

    public void print() {
        System.out.print("The matrix is:");
        System.out.println();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Matrix m1 = new Matrix(2, 3);
        m1.setValue(0, 0, 1);
        m1.setValue(0, 1, 2);
        m1.setValue(0, 2, 3);
        m1.setValue(1, 0, 4);
        m1.setValue(1, 1, 5);
        m1.setValue(1, 2, 6);

        m1.print();

    }
}

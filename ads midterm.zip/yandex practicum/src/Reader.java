public class Reader {
    String fullName;
    String cardNumber;
    String facultyName;
    String dateBirth;
    String phoneNumber;
    String myArray[] = new String[5];
    Reader(String fullName, String cardNumber, String facultyName, String dateBirth, String phoneNumber) {
        this.fullName = fullName;
        this.cardNumber = cardNumber;
        this.facultyName = facultyName;
        this.dateBirth = dateBirth;
        this.phoneNumber = phoneNumber;
        myArray[0] = fullName;
        myArray[1] = cardNumber;
        myArray[2] = facultyName;
        myArray[3] = dateBirth;
        myArray[4] = phoneNumber;
    }
    public void takeBook(int numberBooks) {
        System.out.println(fullName + " took " + numberBooks + " books");
    }
    public void takeBook(String nameBook, String twoBook, String threeBook) {
        System.out.println(fullName + " took books: " + nameBook + ", " + twoBook + ", " + threeBook) ;
    }
    public void returnBook(int numberBooks) {
        System.out.println(fullName + " returned " + numberBooks + " books");
    }
    public void returnBook(String nameBook, String twoBook, String threeBook) {
        System.out.println(fullName + " returned books: " + nameBook + ", " + twoBook + ", " + threeBook);
    }
    public static void main(String[] args) {
        Reader userOne = new Reader("Petrov VV", "777", "SE", "19.02.2005", "87013954515");
        userOne.takeBook(3);
        userOne.takeBook("Adventures", "Dictionary", "Encyclopedia");

        Book oneBook = new Book("Adventures", "Ali");
        Book twoBook = new Book("Dictionary", "Darmen");
        Book threeBook = new Book("Encyclopedia", "Serzhan");

        userOne.returnBook(3);
    }
}

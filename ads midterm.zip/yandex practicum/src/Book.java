public class Book {
    public String name;
    public String author;
    Book(String name, String author) {
        this.name = name;
        this.author = author;
    }
}
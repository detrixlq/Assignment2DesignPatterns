public class Person {
    // variables
    String fullName;
    int age;

    // constructors
    public Person() {
        // default constructor
    }

    public Person(String fullName, int age) {
        this.fullName = fullName;
        this.age = age;
    }

    // methods
    public void move() {
    }

    public void talk() {
        System.out.println(fullName + " is talking");
    }

    public String getTalkingMessage() {
        return fullName + " is talking";
    }
    public static void main(String[] args) {
        Person person = new Person("Ali Atchibayev", 17);
        String message = person.getTalkingMessage();
    }
}


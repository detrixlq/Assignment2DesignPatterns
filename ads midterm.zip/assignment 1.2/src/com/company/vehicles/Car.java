package com.company.vehicles;

public class Car {
    private String brand;
    private String carClass;
    private int weight;
    private Driver driver;
    private Engine motor;

    public Car(String brand, String carClass, int weight, Driver driver, Engine motor) {
        this.brand = brand;
        this.carClass = carClass;
        this.weight = weight;
        this.driver = driver;
        this.motor = motor;
    }

    public void start() {
        System.out.println("Let's go!");
    }

    public void stop() {
        System.out.println("Let's stop!");
    }

    public void turnRight() {
        System.out.println("Turn right!");
    }

    public void turnLeft() {
        System.out.println("Turn left!");
    }

    public String toString() {
        return "Car: " + brand + " Class: " + carClass + " Weight: " + weight + " Driver: " + driver.getFullName() + " Driving Experience: " + driver.getDrivingExperience() + " Engine: Power: " + motor.getPower() + " Manufacturer: " + motor.getManufacturer();
    }
}




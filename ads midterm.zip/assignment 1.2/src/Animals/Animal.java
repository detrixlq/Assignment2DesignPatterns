package Animals;

class Animal {
    private String food;
    private String location;

    public Animal(String food, String location) {
        this.food = food;
        this.location = location;
    }

    public void makeNoise() {
        System.out.println("Such an animal is sleeping");
    }

    public void eat() {
        System.out.println("Animal eat");
    }

    public void sleep() {
        System.out.println("Animals sleep");
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}

class Dog extends Animal {
    public Dog(String food, String location) {
        super(food, location);
    }

    public void makeNoise() {
        System.out.println("Woof woof");
    }

    public void eat() {
        System.out.println("Dogs eat meat");
    }
}

class Cat extends Animal {
    public Cat(String food, String location) {
        super(food, location);
    }

    public void makeNoise() {
        System.out.println("Meow Meow");
    }

    public void eat() {
        System.out.println("Cats eat meat");
    }
}

class Horse extends Animal {
    public Horse(String food, String location) {
        super(food, location);
    }

    public void makeNoise() {
        System.out.println("Hoof Hoof");
    }

    public void eat() {
        System.out.println("Horses eat hay");
    }
}
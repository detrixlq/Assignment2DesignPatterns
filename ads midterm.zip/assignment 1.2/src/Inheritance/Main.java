package Inheritance;

public class Main {

}



public interface ISkill {
    void useSkill();
}

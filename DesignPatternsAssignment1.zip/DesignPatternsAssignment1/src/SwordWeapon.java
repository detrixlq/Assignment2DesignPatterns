public class SwordWeapon implements IWeapon {
    @Override
    public void useWeapon(){
        System.out.println("I wield my sword!");
    }
}

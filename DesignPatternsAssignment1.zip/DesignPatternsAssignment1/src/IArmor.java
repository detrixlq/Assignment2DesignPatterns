public interface IArmor {
    void wearArmor();
}

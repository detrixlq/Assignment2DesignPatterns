public class FireSkill implements ISkill{
    @Override
    public void useSkill() {
        System.out.println("I cast fireballs!");
    }
}

public class CullingSkill implements ISkill {
    @Override
    public void useSkill() {
        System.out.println("I use culling blade!");
    }
}

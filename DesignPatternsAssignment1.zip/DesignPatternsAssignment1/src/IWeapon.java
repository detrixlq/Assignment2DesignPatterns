public interface IWeapon {
    void useWeapon();
}

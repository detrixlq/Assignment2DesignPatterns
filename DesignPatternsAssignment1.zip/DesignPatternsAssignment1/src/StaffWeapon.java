public class StaffWeapon implements IWeapon {
    @Override
    public void useWeapon() {
        System.out.println("I carry my mighty staff!");
    }
}

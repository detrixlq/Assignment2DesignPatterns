public class LightArmor implements IArmor {
    @Override
    public void wearArmor() {
        System.out.println("I wear a light armor.");
    }
}

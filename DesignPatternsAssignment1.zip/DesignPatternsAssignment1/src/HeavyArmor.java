public class HeavyArmor implements IArmor {
    @Override
    public void wearArmor() {
        System.out.println("I wear a heavy armor.");
    }
}

public class AxeWeapon implements IWeapon {
    @Override
    public void useWeapon() {
        System.out.println("I swing my axe!");
    }
}

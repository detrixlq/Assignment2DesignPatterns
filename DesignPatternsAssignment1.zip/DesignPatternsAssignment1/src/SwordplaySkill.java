public class SwordplaySkill implements ISkill{
    @Override
    public void useSkill() {
        System.out.println("I use swordplay!");
    }
}

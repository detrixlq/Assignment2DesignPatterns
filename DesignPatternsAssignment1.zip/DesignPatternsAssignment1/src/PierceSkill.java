public class PierceSkill implements ISkill{
    @Override
    public void useSkill() {
        System.out.println("I use my piercing arrows!");
    }
}
